# Programa gestión de eventos

## Acciones posibles

### Evento

- Crear desde un organizador
- Modificar, setter de los atributos de evento
- Info evento
- Modificar Organizador
- Modificar Categoría
- Modificar telefono

### Gestion 

- Listar todos los eventos
- Filtrar por categoria
- Guardar usuarios
- Guardar organizadores
- Guardar ubicaciones
- Lista de los usuarios
- Metodo de iniciar sesion
- Borrar usuarios
- Crear evento
- Borrar evento, de un organizador
- Listar eventos de un organizador
- Lista de las ubicaciones
- Listar eventos de un usuario

### Usuario

- Crear (constructor)
- Modificar, setters
- Telefono

### Organizador

- Setters y getters
- Telefono


### Ubicacion

- Setter y getters




